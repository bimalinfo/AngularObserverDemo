export class Emp {
	id:string;
	name: string;
  email: string;
  age: string;
  phone: string;
  country: string;
}
